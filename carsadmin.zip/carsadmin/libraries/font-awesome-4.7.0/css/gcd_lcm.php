<?php

function getGcd($a,$b){
    if($b==0){
       return $a;
    } else{
      return getGcd($b,$a%$b);
    }
}
function getLcm($a,$b){
       return getLcm($a *$b)/getGcd($a,$b);
}
$num1=$_POST['num1'];
$num2=$_POST['num2'];

echo("You entered $a and $b");
echo("The Gcd of $ num1 and $num2 is".getGcd($num1,$num2));
echo("The Lcm of $ num1 and $num2 is".getGcd($num1,$num2));




?>