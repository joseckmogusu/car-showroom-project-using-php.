angular.module('adminApp',['ngRoute']).config(function($routeProvider){
	$routeProvider
	.when('/',{
		templateUrl:'../views/dashboarddata.php'
	})
	.when('/notification',{
		templateUrl:'../views/notifications.html',
		controller:'notificationsController',
		controllerAs:'notificationsCtrl'
	})
	.when('/password',{
		templateUrl:'../views/password.html'
	})
	.otherwise({redirectTo:'/'});
}).controller('notificationsController',['$http','$route',function($http,$route){
	var self = this
	$http.get('http://localhost/carsadmin/api/notifications.php').then(function(response){
		self.notifications = response.data
		console.log(self.notifications)
	},function(err){
		alert("An error occured")
		console.log(err)
	})

	self.deleteNotification = function(id,sender_id){
		var payload = {'id':id,'sender_id':sender_id}
		$http.post('/carsadmin/api/deletenotification.php',payload).then(function(response){
			if(response.data.status === 'success'){
				$route.reload()
				alert('Deleted')
			}
		},function(err){
			alert("An error occured")
			console.log(err)
		})
	},

	self.approveCar = function(car_plate,id,user_national_id){
		var payload = {'plate_number':car_plate,'notification_id':id,'national_id':user_national_id}
		$http.post('/carsadmin/api/approvecar.php',payload).then(function(response){
			if(response.data.status === 'success'){
				$route.reload()
				alert('Successfully approved')
			}
		}, function(err){
			alert('An error occured')
			console.log(err)
		})
	}
}])