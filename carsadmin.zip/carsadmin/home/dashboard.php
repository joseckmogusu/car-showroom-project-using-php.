<?php
  session_start();

  if(isset($_SESSION['user'])){
      //user is  logged  in the system
  }
  else{
    //Redirect them to the login page
    header("Location:http://localhost/carsadmin/");
  }
?>
<!DOCTYPE html>
<html class="no-print">
<head>
  <style type="text/css">
    #title{
      color:blue;
    }
    #slide-out{
      width: 200px;
    }
  </style>
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../libraries/font-awesome-4.7.0/css/font-awesome.css">
  <link rel="stylesheet" type="text/css" href="../libraries/css/materialize.min.css">
  <link rel="stylesheet" type="text/css" href="../libraries/css/alertify.min.css">
  <link rel="stylesheet" type="text/css" href="../libraries/css/alertify.css">
  <link rel="stylesheet" type="text/css" href="../css/dashboard.css">
  <script type="text/javascript" src="../libraries/js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="../libraries/js/materialize.min.js"></script>
    <script type="text/javascript" src="../libraries/js/alertify.min.js"></script>
      <script type="text/javascript" src="../libraries/js/alertify.js"></script>
  <script type="text/javascript" src="../libraries/js/angular.min.js"></script>
  <script type="text/javascript" src="../libraries/js/angular-route.min.js"></script>
  <script type="text/javascript" src="../js/module.js"></script>


</head>
<body ng-app="adminApp"  >
  <div class="navbar-fixed col s12 m12 l12" >
  <nav class="#3e2723 brown darken-4 z-depth-0" style="height:70px;">
      <div class="nav-wrapper">
       <ul class="hide-on-med-and-down left" style="padding-left: 240px;margin-top:10px;">
         <li style="font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif,'Apple Color Emoji','Segoe UI Emoji',' UI Symbol';font-size: 18px;font-weight: 300;letter-spacing: -0.5px;" class="blue-text text-lighten-1 far-right">Welcome admin,<?php  echo"$_SESSION[user]"; ?> </li>
       </ul>
       <a href="dashboard.php" style="padding-left: 10px;" class="left tooltipped hide-on-large-only" data-position="bottom" data-delay="50" data-tooltip="Home"><i class="fa f2a-home fa-2x"></i></a>
       <a data-activates="mobile-nav" class="button-collapse right tooltipped" data-position="bottom" data-delay="50" data-tooltip="Menu"><i class="fa fa-bars fa-2x"></i></a>
          <ul id="nav-mobile" class="white-text text-lighten-3 hide-on-med-and-down right" >
          <li class="far-right"><a style="font-size: 14px;font-family: 'Roboto';margin-top: 20px;" class="modal-trigger red-text" href="">
            <!--<?php echo"$_SESSION[user]"; ?>,&nbsp;<i class="fa fa-sign-out fa-1x"></i>Logout</a></li> 
            <li class="grey-text far-right" style="font-size: 15px;font-family: 'Roboto';"><i class="fa fa-user fa-1x"></i></li>
         -->
             
          </ul>
         </div>
     </nav>
   </div>
     <ul id="slide-out" class="side-nav fixed #3e2723 brown darken-4 z-depth-0" style="border-right: none;width: 240px;">
      <br /><br />
        <li>
          <div class="row valign-wrapper">
            <div class="col s5" style="margin-left: 55px;">
              <img src="../images/logo.jpg" alt="" class="circle responsive-img">

            </div>
            <li><div class="divider"></div></li>
          </div>

        </li>
        
        <ul class="collapsible white-text" id="header" data-collapsible="accordion">
          <a class="white-text" href="dashboard.php">
            <li>
              <div class="collapsible-header dashboard" style="font-size: 10px;"><i class="fa fa-dashboard" id="dashboard"></i>Admin Dashboard</div>
            </li>
          </a>
          <li><div class="divider"></div></li>
          <a class="white-text" href="#notification">
            <li>
              <div class="collapsible-header notification" style="font-size: 10px;"><i class="fa fa-bell-o" id="dashboard"></i>NOTIFICATIONS</div>
            </li>
          </a>
           <li><div class="divider"></div></li>
          <a class="white-text" href="#password">
            <li>
              <div class="collapsible-header password" style="font-size: 10px;"><i class="fa fa-edit" id="dashboard"></i>CHANGE PASSWORD</div>
            </li>
          </a>
          
        </ul>
    </ul>
    
  <div class="row" style="margin-top:-20px;padding-left: 250px";>
    <!--The page title of the system -->
    <ul class="collection with-header container"  style="width:99%;margin-top:30px;height: 50px;margin-left:-1px!important;">
        <li class="collection-header">
          <div class="row">
            <div  class="col s12 m4 l4"></div>
            <div class="col s12 m5 l5">
              <span id="title">
                Main dashboard
              </span>
            </div>
            <div class="col s12 m3 l3"></div>
         </div>
        </li>
    </ul>
    <ul class="collection" style="width: 99%">
          <div ng-view >
            
        </div>
       
    </ul>
        
  </div>
<!--end body-->
</body>

</html>

<script type="text/javascript">

  //title bar
   $('.dashboard').click(function(){
      $('#title').html("Main Dashboard").show();
    })
    $('.addcar').click(function(){
      $('#title').html("ADD CAR").show()
      })

    $('.notification').click(function(){
       $('#title').html("CHECK NOTIFICATIONS").show()
      })
      $('.profile').click(function(){
        $('#title').html("MANAGE PROFILE").show()
      })
       $('.password').click(function(){
          $('#title').html("CHANGE PASSWORD").show()
      })

    $(document).ready(function(){
    $('form').submit(function(event){
      event.preventDefault();
    });

    
  })
</script>
