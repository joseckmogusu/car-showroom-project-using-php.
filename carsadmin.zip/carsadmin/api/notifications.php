<?php

session_start();
if(!isset($_SESSION['uid'])){
	header('location:/carsadmin/?logged_in=false');
	exit();
}
if('GET' == $_SERVER['REQUEST_METHOD']){
	getMyNotifications();
}



function getMyNotifications(){
	header('Content-type:application/json');
	//retreive notifications from database
	$conn = new PDO("mysql:host=localhost;dbname=cars;","root","");
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	$query = "SELECT register.email AS email,register.fname AS firstname,register.lname AS lastname,register.id AS national_id,register.contact AS phone,register.pin AS kra,notification.car_name,notification.car_plate,notification.id,notification.s_date,notification.s_time FROM register RIGHT JOIN notification ON register.id=notification.sender_id;";
	$stmt = $conn->prepare($query);
	try{
		$stmt->execute();
		$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($results);
		$conn = null;
	}catch(PDOException $e){
		$response['status'] = 'error';
		$response['mesasge'] = 'Internal server error';
		echo json_encode($response);
	}

}




?>