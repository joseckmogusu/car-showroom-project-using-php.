<?php
session_start();
ini_set('display_errors','off');
error_reporting(E_ALL);
ini_set('log_errors','on');
ini_set('error_log','error_log.log');

if('POST' == $_SERVER['REQUEST_METHOD']){
	$request = json_decode(file_get_contents("php://input"));
	approveCar($request->plate_number,$request->notification_id,$request->national_id);
}

function approveCar($plates,$notification_id,$user_id){
	header('Content-type:application/json');
	$response = array();
	$conn = new PDO("mysql:host=localhost;dbname=cars","root","");
	$query1 = "UPDATE car SET is_approved = ?  WHERE plate_number = ?";
	$query2 = "DELETE FROM notification WHERE id = ?";
	$query3 = "INSERT INTO usernotification(user_id,message)VALUES(?,?)";
	$message = "The car with plate number [".$plates."] was approved for sale on ".date('d-m-Y')." at ".date('h:i:sa')."";
	try{
		$stmt = $conn->prepare($query1);
		$conn->beginTransaction();
		$stmt->execute(array(1,$plates));
		$stmt = null;
		$stmt = $conn->prepare($query2);
		$stmt->execute(array($notification_id));
		$stmt = null;
		$stmt = $conn->prepare($query3);
		$stmt->execute(array($user_id,$message));
		$conn->commit();
		$response['status'] = 'success';
		$response['message'] = "Car approved";
		$response['plates'] = $plates;

	}catch(PDOException $e){
		$response['status'] = 'error';
		$response['message'] = "An error occured";
	}
	$conn = null;
	echo json_encode($response);
}


?>