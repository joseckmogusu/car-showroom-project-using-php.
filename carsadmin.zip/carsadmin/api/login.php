<?php

	ini_set('display_errors','off');
	error_reporting(E_ALL);
	ini_set('log_errors','on');
	ini_set('error_log','error_log.log');

	session_start();

	if("POST" ==$_SERVER['REQUEST_METHOD']){

		$email=$_POST['email'];
		$pword=$_POST['pword'];

		login($email,$pword);
	}
	function login($email,$pword){		
		$response=array();
		if(strlen($email)==0){
			$response['email_error']="Input your email address";
		}else{
			$email=$email;
		}
		if(strlen($pword)==0){
			$response['pword_error']="Input your password";
		}else{
			$pword = $pword;
		}


		if(!empty($response)){
			header("Content-type:application/json");
			echo json_encode($response);
		}else{
			$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
			$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

			$sql="SELECT id,adminname FROM admin where email=? AND password=?";
			$stmt=$conn->prepare($sql);
			$stmt->execute(array($email,$pword));
			$results=$stmt->fetch(PDO::FETCH_ASSOC);

			

			if($results){
				$_SESSION['user']=$results['adminname'];
				$_SESSION['uid'] = $results['id'];
				$response['status']="success";
				$response['message']="successfuly logged in";
				$conn = null;

			}
			else{
				$response['status']="error";
				$response['message']="email or password is incorrect";
			}
			header("Content-type:application/json");
			echo json_encode($response);
		}
	}
?>