<?php
  ini_set('display_errors','off');
  error_reporting(E_ALL);
  ini_set('log_errors','on');
  ini_set('error_log','error_log.log');
  
  $conn=new PDO("mysql:host=localhost;dbname=cars","root","");
  $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

  $sql = "SELECT car.car_name,car.car_model,car.car_type,car.car_cost,car.car_description,car.year_of_manufacture,car.is_negotiable,register.contact FROM car left join register on car.user_id = register.id WHERE is_approved = ?";
  $stmt = $conn->prepare($sql);
  $stmt->execute(array(1));
  $cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
  $conn = null;
  


?>
<!DOCTYPE html>
<html>
<head>
	<title>vehicle showroom for used cars</title>
	<link rel="shortcut icon" href="images/logo1.png">


	<link rel="stylesheet" type="text/css" href="libraries/css/materialize.min.css">
	<script type="text/javascript" src="libraries/js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="libraries/js/materialize.min.js"></script>
	<style type="text/css">
	.btn{
	width:100%;
    border: none;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
}
.footer {
	width:100%;
	border:none;
	color:red;
}

	    .error{
	    	width:92%;
	    	margin:0px auto;
	    	padding:0px;
	    	border:1px solid #a94442;
	    	background:#f2dede;
	    	color:#a94442;
	    	border-radius: 5px;
	    	text-align: left;
	    }
		.auth_{
			color: rgb(13,13,13)!important;
			font-family: "Roboto",sans-serif;
			font-weight: 300;
			font-size: 16px;
		}
		.major_links{
			color: #fff!important;
			font-family: "Roboto",sans-serif;
			font-weight: 300;
			font-size: 16px;
		}
		header, main, footer {
	      padding-left: 300px;
	    }

	    @media only screen and (max-width : 992px) {
	      header, main, footer {
	        padding-left: 0;
	      }
	    }


	    body{
		    display: flex;
		    min-height: 100vh;
		    flex-direction: column;
		  }

		main{
		    flex: 1 0 auto;
		  }
	</style>
</head>
<body>
	
	<?php
		include 'views/website.php';
	?>
	<div class="row">
    <?php
    foreach ($cars as $car) {
      echo "<div class='col s12 m4 l4'>";
      echo "<div class='card'>";
      echo "<div class='card-image'>";
      echo "<img src='images/car2.jpg'>";
      echo "<span class='card-title'>".$car['car_name']."</span>";
      echo "</div>";
      echo "<div class='card-content'>";
      echo "<p>MODEL: ".$car['car_model']."<br />TYPE:".$car['car_type']."<br />DESCRIPTION:".$car['car_description']."<br />COST:".$car['car_cost']."<br />YEAR:".$car['year_of_manufacture']."
      </p></div>";
      echo "<div class='card-action>";
      echo "<a style='cursor:pointer;' href='#'><span class='contact-seller' id='".$car['contact']."' style='color:orange;cursor:pointer;'>Contact seller</span></a></div></div></div>";

    }

    ?>
  </div>
            
            
            
 

	
	<?php include 'views/footer.php'; ?>
	<div style="heigth:500px"></div>
</body>
</html>
<script type="text/javascript" src="libraries/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="libraries/materialize.min.js"></script>
<script type="text/javascript" src="libraries/sweetalert.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
<script type="text/javascript">
		$(document).ready(function(){
			 $('.slider').slider();
       $(document).on('click','.contact-seller',function(){
        var phone = this.id
        $.ajax({
          type:'POST',
          url:'Api/sendsms.php',
          data:{'seller-phone':phone},
          dataType:'json',
          success:function(response){
            alert('Notification sent to seller successfully')
          }, error:function(err){
            alert('please login')
          }
        })
       })
    });        
          
</script>
