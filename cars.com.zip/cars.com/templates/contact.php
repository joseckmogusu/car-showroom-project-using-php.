<!DOCTYPE html>
<html>
<head>
	<title>online vehicle showroom for used cars</title>
	<link rel="shortcut icon" href="../images/logo1.png">


	<link rel="stylesheet" type="text/css" href="../libraries/css/materialize.min.css">
	<script type="text/javascript" src="../libraries/js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="../libraries/js/materialize.min.js"></script>
	<style type="text/css">
	.btn{
	width:100%;
    border: none;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
}

	    .error{
	    	width:92%;
	    	margin:0px auto;
	    	padding:0px;
	    	border:1px solid #a94442;
	    	background:#f2dede;
	    	color:#a94442;
	    	border-radius: 5px;
	    	text-align: left;
	    }
		.auth_{
			color: rgb(13,13,13)!important;
			font-family: "Roboto",sans-serif;
			font-weight: 300;
			font-size: 16px;
		}
		.major_links{
			color: #fff!important;
			font-family: "Roboto",sans-serif;
			font-weight: 300;
			font-size: 16px;
		}
		header, main, footer {
	      padding-left: 300px;
	    }

	    @media only screen and (max-width : 992px) {
	      header, main, footer {
	        padding-left: 0;
	      }
	    }


	    body{
		    display: flex;
		    min-height: 100vh;
		    flex-direction: column;
		  }

		main{
		    flex: 1 0 auto;
		  }
	</style>
</head>
<body>
	
	<div class="row float-right" style="margin-right:100px;">
	<div class="col s12 m12 l12">
		<nav class="z-depth-0" style="background-color: #fff;">
		    <div class=" nav-wrapper blue">
		      <ul id="nav-mobile" class="right hide-off-med-and-down 1a237e indigo darken-5">
		        <li><a  class="auth_ "  href="http://localhost/cars.com/login.html">LOGIN</a></li>
		        <li><a  class="auth_"  href="http://localhost/cars.com/register.html">REGISTER</a></li>
		      </ul>
		    </div>
  		</nav>
	</div>
</div>	

	 <nav>
    <div class="nav-wrapper 1a237e indigo darken-5">
      <a href="" class="brand-logo"><img src="images/logo.png" style="height:40px;width:100px;"></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down container">
        <li><a href="../index.php">HOME</a></li>
	    <li><a class="major_links" href="about.php">ABOUT-US</a></li>
	    <li><a class="major_links" href="contact.php">CONTACT-US</a></li>
      </ul>
    </div>
  </nav>
  <br/>
  <div class="col s12 m12 l12 grey">

      <p class="white-text">For more inquiry about our services, you can visit our offices in GPO House,Nairobi. you can us through the following websites contact</p>
      <p class="white-text">contact us through our P.O BOX 30025, NAIROBI</p>
      <p class="white-text"> call via our safaricom contact: 0718713840 or airtel: 0736133045</p>
      	<p class="white-text">Email through OVS@cars.africa</p>
      	
        
	
</div>
	
	<?php include '../views/footer.php'; ?>
	<div style="heigtht:500px"></div>
</body>
</html>
<script type="text/javascript" src="../libraries/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="../libraries/materialize.min.js"></script>
<script type="text/javascript" src="../libraries/sweetalert.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
<script type="text/javascript">
		$(document).ready(function(){
			 $('.slider').slider();
    });        
          
</script>
