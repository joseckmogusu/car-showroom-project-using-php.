angular.module('adminApp').factory('Picupload',['$http',function($http){
	return{
		upload:function(update,item){
			var item=new FormData();
			return $http.post(update,item).then(function(response){
				return response.data;
			},function(errResponse){
				console.log("An error occured");
			})
		}
	}
}])