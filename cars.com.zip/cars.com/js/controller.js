angular.module('adminApp').controller('SubCtrl',['Picupload',function(Picupload){
	var self=this;
	//self.myFile={};
	self.user={};
	self.upload=function(item){
		var item=self.myFile;
		Picupload.upload('../functions/upload.php',item).then(function(response){
			self.item={};
		})

	}
}])
//
.controller('DashboardCtrl',[function(){
	this.currentTab='tab1';
	this.currentTab='tab2';
	this.currentTab='tab3';
	this.currentTab='tab4';
	this.currentTab='tab5';

}])