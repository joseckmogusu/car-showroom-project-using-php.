
angular.module('adminApp',['ngRoute']).config(function($routeProvider){
	$routeProvider
	.when('/',{
		templateUrl:'../views/dashboarddata.php'
	})
	.when('/addcar',{
		templateUrl:'../views/addcars.html'
	})
	.when('/notification',{
		templateUrl:'../views/notification.html',
		controller:'notificationsController',
		controllerAs:'notificationsCtrl'
	})
	.when('/profile',{
		templateUrl:'../views/profile.html'
	})
	.when('/password',{
		templateUrl:'../views/changepass.html'
	})
	.otherwise({redirectTo:'/'});
}).controller('notificationsController',['$http','$route',function($http,$route){
	var self = this
	$http.get('/cars.com/Api/notification.php').then(function(response){
		self.notifications = response.data
		console.log(self.notifications)
	},function(err){
		alert("An error occured")
		console.log(err)
	})
	self.deleteNotification = function(id){
		var payload = {'id':id}
		$http.post('/cars.com/Api/deletenotification.php',payload).then(function(response){
			if(response.data.status === 'success'){
				$route.reload()
				alert('Notification deleted')
			}
		},function(err){
			alert("An error occured")
			console.log(err)
		})
	}
}])