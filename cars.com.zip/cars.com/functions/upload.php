<?php
    ini_set('display_errors','off');
    error_reporting(E_ALL);
    ini_set('log_errors','on');
    ini_set('error_log','error_log.log');
if($_FILES['file']['name'] !=''){
        $extension=end(explode(".",$_FILES['file']['name']));
        $allowed_type=array("jpg","jpeg","png","gif");
        if(in_array($extension, $allowed_type)){
                $_new_name=rand().".".$extension;
                $path="images/".$_new_name;

        }else{
                echo '<script>alert("Invalid File Format")</script>';
        }
}else{
        echo '<script>alert("Please select file")</script>';
}


?>