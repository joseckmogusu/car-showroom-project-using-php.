
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="row float-right" style="margin-right:100px;">
	<div class="col s12 m12 l12">
		<nav class="z-depth-0" style="background-color: #fff;">
		    <div class=" nav-wrapper">
		      <ul id="nav-mobile " class="right hide-off-med-and-down 1a237e indigo darken-5">
		        <li><a  class="auth_ " id="login" href="http://localhost/cars.com/login.html">LOGIN</a></li>
		        <li><a  class="auth_" id="register" href="http://localhost/cars.com/register.html">REGISTER</a></li>
		      </ul>
		    </div>
  		</nav>
	</div>
</div>	

	 <nav>
    <div class="nav-wrapper 1a237e indigo darken-5" >
      <a href="" class="brand-logo"><img src="images/logo.png" style="height:40px;width:100px;"></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down container">
        <li><a href="index.php">HOME</a></li>
	    <li><a class="major_links" href="templates/about.php">ABOUT-US</a></li>
	    <li><a class="major_links" href="templates/contact.php">CONTACT-US</a></li>
	    <li><a class="major_links" href="home/dashboard.php">SELL-CAR</a></li>
      </ul>
    </div>
  </nav>
  <br/>
  <div class="row container col s12 m12 l12">

        
	
</div>
</header>
</body>
</html>
<script type="text/javascript">
	$(document).ready(function() {
    $('select').material_select();
  });
            
</script>