<style type="text/css">
	#border1,#border2,#border3,#border4{
      border-color: lightgrey;
      color:blue;
      height: 170px;
      width: 220px;
      margin-left: 160px;
      margin-top: 20px;
      text-align: center;
	}
</style>

<form class="container" ng-controller="DashboardCtrl as dashboardCtrl" style="margin-left:150px;margin-top:50px;">	
<div class="row">
<div class="col s12 l6 m6 collection" ng-click="dashboardCtrl.currentTab='tab1'" id="border1">
<br/>
<i class="far far-right fa fa-car  fa-5x"><a href="addcars.html" ></i>
<br/>
<a class="waves-effect waves-teal btn-flat" >ADD CARS</a>

</div>
<div class="col s12 m6 l6  collection" ng-click="dashboardCtrl.currentTab='tab2'" id="border2">
<br>
<i class=" fa fa-bell-o  fa-5x"><a href="notification.html"></i>
<br/>
<a class="waves-effect waves-teal btn-flat">NOTIFICATIONS</a>

</div>
</div>
<div class="row">
<div class="col s12 l6 m6  collection" ng-click="dashboardCtrl.currentTab='tab3'" id="border3" >
<br/>
<i class="fa fa-user  fa-5x"><a href="profile.html"></i>
<br/>
<a class="waves-effect waves-teal btn-flat">MANAGE PROFILE</a>

</div>
<div class="col s12 m6 l6  collection" ng-click="dashboardCtrl.currentTab='tab4'" id="border4">
<br/>
<i class="fa fa-edit fa-5x"><a href="changepass.html"></i>
<br/>
<a class="waves-effect waves-teal btn-flat">CHANGE PASSWORD</a>

</div>
</div>
<div ng-switch on="dashboardCtrl.currentTab">
	<div ng-switch-when="tab1">
		<div ng-include="'../views/addcars.html'";></div>
	</div>
	<div ng-switch-when="tab2">
		<div ng-include="'../views/addcars.html'";></div>
	</div>
	<div ng-switch-when="tab3">
		<div ng-include="'../views/addcars.html'";></div>
	</div>
	<div ng-switch-when="tab4">
		<div ng-include="'../views/addcars.html'";></div>
	</div>
	
	<div ng-switch-when="tab5">
		
	</div>
	
</div>
</form>
<br/>
<script type="text/javascript">
	$(document).ready(function(){
		$.ajax({
	      type:'GET',
	      url:'../Api/users.php',
	      dataType:'json',
	      success:function(response){
	        //admnister permissions
	        $('#border1').mouseover(function(){
	        	$('#border1').css('background-color','red');
	        	$('#border1').click(function(){
	        		$('#border1').hide();
	        		$('#border2').hide();
	        		$('#border3').hide();
	        		$('#border4').hide();
	        	})
	        })
	        $('#border1').mouseout(function(){
	        	$('#border1').css('background-color','white');
	        })
	      },error:function(err){
	        console.log(err);
	      }
    	})
	})
</script>
