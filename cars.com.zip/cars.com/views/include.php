<?php 
include 'views/db.php';
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Second Hand Cars</title>
	<link rel="shortcut icon" href="images/logo1.png">
	<link rel="stylesheet" type="text/css" href="css/materialize.min.css">
	<link rel="stylesheet" type="text/css" href="css/sweetalert.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">

	<style type="text/css">
	.btn{
	width:100%;
    border: none;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
}

	    .error{
	    	width:92%;
	    	margin:0px auto;
	    	padding:0px;
	    	border:1px solid #a94442;
	    	background:#f2dede;
	    	color:#a94442;
	    	border-radius: 5px;
	    	text-align: left;
	    }
		.auth_{
			color: rgb(13,13,13)!important;
			font-family: "Roboto",sans-serif;
			font-weight: 300;
			font-size: 16px;
		}
		.major_links{
			color: #fff!important;
			font-family: "Roboto",sans-serif;
			font-weight: 300;
			font-size: 16px;
		}
		header, main, footer {
	      padding-left: 300px;
	    }

	    @media only screen and (max-width : 992px) {
	      header, main, footer {
	        padding-left: 0;
	      }
	    }


	    body{
		    display: flex;
		    min-height: 100vh;
		    flex-direction: column;
		  }

		main{
		    flex: 1 0 auto;
		  }
	</style>
</head>
<body>
	<?php
		include 'views/include.php';
	?>
	<main>
		<div class="row">
			<div class="col s12 m12 l12">
				<!--paste carousel here!!-->
				    <div class="carousel carousel-slider">
						    <a class="carousel-item" href="#one!"><img src="images/car1 (4).jpg"></a>
						    <a class="carousel-item" href="#two!"><img src="images/car1.jpg"></a>
						    <a class="carousel-item" href="#three!"><img src="images/car2.jpg"></a>
						    <a class="carousel-item" href="#four!"><img src="images/car3.jpg"></a>
						    <a class="carousel-item" href="#five!"><img src="images/car4.jpg"></a>
				  </div>
			</div>
		</div>
	</main>
	<?php include 'views/footer.php'; ?>
	<div style="heigth:500px"></div>
</body>
</html>
<script type="text/javascript" src="libraries/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="libraries/materialize.min.js"></script>
<script type="text/javascript" src="libraries/sweetalert.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>
<script type="text/javascript">
		$(document).ready(function(){
      $('.carousel').carousel();
      //initial carousel-slider
      $('.carousel.carousel-slider').carousel({fullwidth:true});
    });
</script>
