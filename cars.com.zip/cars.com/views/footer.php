 
 <footer class="page-footer #1a237 indigo darken-4" style="background:; width:100%; height:6% ;position:bottom;z-index:99; clear:both; text-align:initial; float:none; display: inline-block; ">
<div class="container row col l12 m12 s12">
  <div class="row row col l12 m12 s12">
    <div class="col l3 m3 s12  #1b5e20 green darken-4 " style="width:30%; height:5%;" >
      <h5 class="white-text">our partners</h5>
      <ul>
        <li><a class="grey-text text-lighten-3" href="www.kra.co.ke">kenya revenue authority</a></li>
        <li><a class="grey-text text-lighten-3" href="www.e-citizen.co.ke">e-citizen</a></li>
        <li><a class="grey-text text-lighten-3" href="www.kebs.co.ke">kebs</a></li>
        </ul>
    </div>

    <div class="col l3 m3 s12 #e65100 orange darken-4 center" style="width:30%; height:5%">
      <h5 class="white-text">Visit us for more inquire</h5>
       <ul>
        <li><a class="grey-text text-lighten-3" href="#">GPO House,Nairob</a></li>
        <li><a class="grey-text text-lighten-3" href="#">9th floor room 514</a></li>
        <li><a class="grey-text text-lighten-3" href="#">P.O  BOX 30025 NAIROB</a></li>
        <li><a class="grey-text text-lighten-3" href="www.gmail.com">Email: OVS@cars.africa</a></li>
        </ul>      
    </div>
    <div class="col l3 m3 s12 offset #bcaaa4 brown lighten-3" style="width:30%; height:5%" >
      <h5 class="white-text"> Quick access</h5>
      <ul>
        <li><a class="grey-text text-lighten-3" href="index.php">HOME</a></li>
        <li><a class="grey-text text-lighten-3" href="templates/about.php">about us</a></li>
        <li><a class="grey-text text-lighten-3" href="templates/contact.php">contact us</a></li>
      </ul>
    </div>
  </div>
</div>
<div class="footer-copyright #263238 blue-grey darken-4 col l12 s12 m12">
  <div class="container red-text " style="width:100%;">
  ©2019 Copyright Developer by otema mogusu joseck 
  @ 0718713840

  </div>
</div>
</footer>