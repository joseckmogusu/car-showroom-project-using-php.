<?php 
    session_start();

    ini_set('display_errors','off');
    error_reporting(E_ALL);
    ini_set('log_errors','on');
    ini_set('error_log','error_log.log');

    if("POST" ==$_SERVER['REQUEST_METHOD']){

    	$carid=$_POST['carid'];
    	$carname=$_POST['carname'];
    	$carmodel=$_POST['carmodel'];
        $cartype=$_POST['cartype'];
    	$cardes=$_POST['cardes'];
    	$carcost=$_POST['carcost'];
    	$year=$_POST['year'];
    	$noge=$_POST['noge'];
        //$pic=$_POST['pic'];
        $id=$_SESSION['uid'];


    	regcar($carid,$carname,$carmodel,$cartype,$cardes,$carcost,$year,$noge,$id);
    
    }
    function regcar($carid,$carname,$carmodel,$cartype,$cardes,$carcost,$year,$noge,$id){


    $response=array();
    if(strlen($carid)==0){
            $response['carid_error']="enter the number plate";
        }else{
            $carid=$carid;
        }
    if(strlen($carname)==0){
            $response['carname_error']="Input name ";
        }else{
            $carname=$carname;
        }
    if(strlen($carmodel)==0){
            $response['carmodel_error']="Input car model ";
        }else{
            $carmodel=$carmodel;
        }
    if(strlen($cartype)==0){
            $response['cartype_error']="Input car fuel type";
        }else{
            $cartype=$cartype;
        }
    if(strlen($cardes)==0){
            $response['cardes_error']="Input car description ";
        }else{
            $cardes=$cardes;
        }
    if(strlen($carcost)==0){
            $response['carcost_error']="Input cost of the car";
        }else{
            $carcost=$carcost;
        }

        if(!empty($response)){
            $response = $response;
        }else{
    


        $conn=new PDO("mysql:host=localhost;dbname=cars","root","");
        $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        $sql = "SELECT car_name FROM car WHERE plate_number = ? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->execute(array($carid));
        $car = $stmt->fetch(PDO::FETCH_ASSOC);
        if($car){
            $response['status'] = 'error';
            $response['message'] = 'The car has already been posted';
        }else{

        $sql="INSERT INTO car(plate_number,car_name,car_model,car_type,car_description,car_cost,year_of_manufacture,is_negotiable,user_id) VALUES(?,?,?,?,?,?,?,?,?)";
       
        $query = "INSERT INTO notification(sender_id,car_name,car_plate,s_date,s_time) VALUES (?,?,?,?,?)";

        try{
            $stmt=$conn->prepare($sql);
            $conn->beginTransaction();
            $stmt->execute(array($carid,$carname,$carmodel,$cartype,$cardes,$carcost,$year,$noge,$_SESSION['uid']));
            $stmt = null;
            $stmt = $conn->prepare($query);
            $stmt->execute(array($_SESSION['uid'],$carname,$carid,date('Y-m-d'),date('h:i:s')));
            $conn->commit();

            $response['status']="success";
            $response['message']='Successfully inserted';
        }catch(PDOExecption $e){

            $conn->rollback();
            error_log($e->getMessage());
            $response['status']="error";
            $response['message']='Error inserting';
        }
        $conn = null;//close database connection
       

    }
    }
     header("Content-type:application/json;charset-UTF=8");
    echo json_encode($response);
}







?>