<?php
session_start();

ini_set('display_errors','off');
error_reporting(E_ALL);
ini_set('log_errors','on');
ini_set('error_log','error_log.log');
if('POST' == $_SERVER['REQUEST_METHOD']){
	$request = json_decode(file_get_contents("php://input"));
	deleteNotification($request->id);
}

function deleteNotification($id){
	header('Content-type:application/json');
	$response = array();
	$conn = new PDO("mysql:host=localhost;dbname=cars","root","");
	$query = "DELETE FROM usernotification WHERE id = ?";
	$stmt = $conn->prepare($query);
	try{
		$conn->beginTransaction();
		$stmt->execute(array($id));
		$conn->commit();
		$response['status'] = 'success';
		$response['message'] = "Post deleted";

	}catch(PDOException $e){
		$response['status'] = 'error';
		$response['message'] = "Error while deleting";
	}
	$conn = null;
	echo json_encode($response);
}


?>