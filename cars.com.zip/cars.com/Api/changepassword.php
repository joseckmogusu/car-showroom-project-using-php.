<?php
 
  ini_set('display_errors','off');
  error_reporting(E_ALL);
  ini_set('log_errors','on');
  ini_set('error_log','error_log.log');

   session_start();

  if ("POST" ==$_SERVER['REQUEST_METHOD']){
  	$oldpword=$_POST['oldpword'];
  	$npword=$_POST['npword'];
  	$cpword=$_POST['cpword'];
     header("content-type:application/json;charset-UTF=8");
    //echo json_encode($passwordresponse);

  	updatepassword($oldpword,$npword,$cpword);
  }
 
  function updatepassword($oldpword,$npword,$cpword){
  	$passwordresponse=array();

  	if(strlen($oldpword)==0){
  		$passwordresponse['oldpword1_error']="input your old password";
  		 	}else{
  		 		$oldpword=$oldpword;
  		 	}
  	if(strlen($npword)==0){
  		$passwordresponse['npword_error']="input your new password";
  	}else{
  		$npword=$npword;
  	}
  	if(strlen($cpword)==0){
  		$passwordresponse['cpword_error']="input your confirmation password";
  	}else{
  		$cpword=$cpword;
  	}


  
    $conn=new PDO("mysql:host=localhost;dbname=cars","root","");
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

    //create aquery
    $query="SELECT pword from register where id=?";
    $stmt=$conn->prepare($query);
    $stmt->execute(array($_SESSION['user']));
    $results=$stmt->fetch(PDO::FETCH_ASSOC);
    $stmt=null;
    echo json_encode($results['pword']);
   // return $results['pword'];


    
    //update the password
    if(strcmp($results['pword'], $oldpword)){
    	//check password match
    	if($npword=$cpword){

    	//create an update query
    	$query2="UPDATE register SET pword=? WHERE id=?";
    	$stmt2=$conn->prepare($query2);

    	try{
    		$conn->beginTransaction();
    		$stmt2->execute(array($npword,$_SESSION['user']));
    		$conn->commit();
    		$passwordresponse['status']='success';
    		$passwordresponse['message']='successfully updated';

    	}catch(PDOExecption $e){
    		$conn->rollback();
    		$passwordresponse['status']='err';
    		$passwordresponse['message']='error occured';

    	}
    }else{
    	$passwordresponse['matchpword_error']="confirmation and new passwords don't match";
    }


    }else{
    	$passwordresponse['oldpword_error']='old and new passwords not matching';



    }
   

  }
?>