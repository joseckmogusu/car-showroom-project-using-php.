<?php
$user_ip='41.89.22.100';
$geo=unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
$city=$geo["geoplugin_city"];
$region=$geo["geoplugin_regionName"];
$country=$geo["geoplugin_countryName"];
echo "city:".$city."<br>";
echo "city:".$region."<br>";
echo "city:".$country."<br>";
 ?>