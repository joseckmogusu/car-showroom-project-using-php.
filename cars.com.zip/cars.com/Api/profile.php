<?php
session_start();
ini_set('display_errors','off');
error_reporting(E_ALL);
ini_set('log_errors','on');
ini_set('error_log','error_log.log');
if("GET" == $_SERVER['REQUEST_METHOD']){
	$response=array();
	$response=details();

	header("Content-type:application/json");
	echo json_encode($response);
}
if("POST" == $_SERVER['REQUEST_METHOD']){
	$residence=$_POST['residence'];
	$contact=$_POST['contact'];
	update($residence,$contact);

	

}

function details(){

	$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

	$sql="SELECT residence,contact,lname from register where lname=?";
	$stmt=$conn->prepare($sql);
	$stmt->execute(array($_SESSION['user']));
	$results=$stmt->fetch(PDO::FETCH_ASSOC);

	return $results;

}
function update($residence,$contact){
	$response=array();
	$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

	$query="UPDATE register  SET residence=?,contact=? WHERE id=?";
	$stmt2=$conn->prepare($query);
	try{
	$conn->beginTransaction();
	$stmt2->execute(array($residence,$contact,$_SESSION['uid']));
	$conn->commit();
	$response['status']="success";
	$response['message']="successfully updated";
	}catch(PDOException $e){
	$conn->rollback();
	$response['status']="error";
	$response['message']="error updating";
	}
	$conn = null;//close connection DB
	
	echoData($response);
}
function echoData($data){
	header("Content-type:application/json");
	echo json_encode($data);
}

