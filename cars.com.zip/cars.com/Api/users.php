
<?php
/*
	session_start();
	if("GET" ==$_SERVER['REQUEST_METHOD']){
		$response=array();
		$response['perm'] = user();
		header("Content-type:application/json");
		echo json_encode($response);
	}

	function user(){
		//create  a connention
		$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
		$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

		//create  a query
		$sql="SELECT permissions  FROM register where lname=?";
		$stmt=$conn->prepare($sql);
		$stmt->execute(array($_SESSION['user']));
		$results=$stmt->fetch(PDO::FETCH_ASSOC);

		return $results['permissions'];

	}
	*/


?>