<?php

session_start();
if(!isset($_SESSION['uid'])){
	header('location:/carsadmin/?logged_in=false');
	exit();
}
if('GET' == $_SERVER['REQUEST_METHOD']){
	getMyNotifications();
}



function getMyNotifications(){
	header('Content-type:application/json');
	//retreive notifications from database
	$conn = new PDO("mysql:host=localhost;dbname=cars;","root","");
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	$query = "SELECT register.id AS ID, usernotification.message,usernotification.id FROM register RIGHT JOIN  usernotification ON register.id=usernotification.user_id; ";
	$stmt = $conn->prepare($query);
	try{
		$stmt->execute();
		$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($results);
		$conn = null;
	}catch(PDOException $e){
		$response['status'] = 'error';
		$response['mesasge'] = 'Internal server error';
		echo json_encode($response);
	}

}




?>