<?php
session_start();
if(!isset($_SESSION['uid'])){
	headerl('location:/');
}
include_once 'AfricasTalkingGateway.php';
if('POST' == $_SERVER['REQUEST_METHOD']){
	$phone = htmlentities(strip_tags(trim($_POST['seller-phone'])));
	$phone = "+254".$phone;
	sendSMS($phone);
}

function sendSMS($phone){
	header('Content-type:application/json');
	$response = array();
	$username   = "kigunda";
	$apikey     = "8f6ebff5b8a5e86990796b62b5b71b9168f7e2d6e8bf8a4bdcaecf774cfb6845";
	$recipients = $phone;
	$gateway    = new AfricasTalkingGateway($username, $apikey);
	try{
		$message    = $_SESSION['user'].", car buyer contacted you\n"."Phone is:+254".$_SESSION['phone']." and email is: ".$_SESSION['email']." GOOD LUCK!!!"; 
		$results = $gateway->sendMessage($recipients, $message);
	  //success

	  $response['status_code'] = 'status';
	  $response['message'] = 'Sent the notification successfully';
	  
	}catch(Exception $e){
		$response['status'] = 'error';
		$response['message'] = 'login please';

	}
	echo json_encode($response);

}

?>