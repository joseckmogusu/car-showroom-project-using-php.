<?php
	ini_set('display_errors','off');
	error_reporting(E_ALL);
	ini_set('log_errors','on');
	ini_set('error_log','error_log.log');

	if("POST" ==$_SERVER['REQUEST_METHOD']){

		$id=$_POST['id'];
		$uname=$_POST['uname'];
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['email'];
		$residence=$_POST['residence'];
		$date=date('Y-m-d');
		$pin=$_POST['pin'];
		$contact=$_POST['contact'];
		$pword=$_POST['pword'];
		//$cpword=$_POST['cpword'];

		register($email,$uname,$fname,$lname,$residence,$date,$pin,$contact,$pword,$id);

	}

	function register($email,$uname,$fname,$lname,$residence,$date,$pin,$contact,$pword,$id){
		$response=array();
	if(strlen($email)==0){
			$response['email_error']="Input your email address";
		}else{
			$email=$email;
		}
	if(strlen($uname)==0){
			$response['uname_error']="Input your username ";
		}else{
			$uname=$uname;
		}
	if(strlen($fname)==0){
			$response['fname_error']="Input your first name ";
		}else{
			$fname=$fname;
		}
	if(strlen($lname)==0){
			$response['lname_error']="Input your last name";
		}else{
			$lname=$lname;
		}
	if(strlen($residence)==0){
			$response['residence_error']="Input your residence ";
		}else{
			$residence=$residence;
		}
	if(strlen($pin)==0){
			$response['pin_error']="Input your kra pin";
		}else{
			$pin=$pin;
		}
	if(strlen($contact)==0){
			$response['contact_error']="Input your contact";
		}else{
			$contact=$contact;
		}
	if(strlen($pword)==0){
			$response['pword_error']="Input your password";
		}else{
			$pword=$pword;
		}
	if(strlen($id)==0){
			$response['id_error']="Input your national id";
		}else{
			$id=$id;
		}
		if(!empty($response)){
            $response = $response;
        }else{    
			$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
			$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

			$sql = "SELECT id FROM register WHERE email = ? LIMIT 1";
			$stmt = $conn->prepare($sql);
			$stmt->execute(array($email));
			$register = $stmt->fetch(PDO::FETCH_ASSOC);

			if($register){
				$response['status'] = 'error';
				$response['message'] = 'The email has been used';
			 }else{

			//create  query
			$query="INSERT INTO register(email,uname,fname,lname,residence,date,pin,contact,pword,id) VALUES(?,?,?,?,?,?,?,?,?,?)";
			$stmt=$conn->prepare($query);

			try{
				$conn->beginTransaction();
				$stmt->execute(array($email,$uname,$fname,$lname,$residence,$date,$pin,$contact,$pword,$id));
				$conn->commit();

				$response['status']='success';
				$response['message']='Successfully inserted';
			}catch(PDOException $e){

				$conn->rollback();
				$response['status']='error';
				$response['message']='Error inserting';
			}
			$conn = null;//close database connection

		    }
	}
	header("Content-type:application/json");
	echo json_encode($response);



	}


?>