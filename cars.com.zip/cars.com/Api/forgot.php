<?php

	ini_set('display_errors','off');
	error_reporting(E_ALL);
	ini_set('log_errors','on');
	ini_set('error_log','error_log.log');
	
	if("POST" == $_SERVER['REQUEST_METHOD']){

		$email=$_POST['email'];
		$pword=$_POST['pword'];
		$cpword=$_POST['cpword'];

		forgot($email,$pword,$cpword);

	}

	function forgot($email,$pword,$cpword){
		$response=array();

		if(strlen($email)==0){
			$response['email_error']="input email";

		}else{
			$email=$email;
		}

		if(strlen($pword)==0){
			$response['pword_error']="input password";

		}else{
			$pword=$pword;
		}

		if(strlen($cpword)==0){
			$response['cpword_error']="Confirmation password required";

		}else{
			$cpword=$cpword;
		}
	
	$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


	//create query
	$query="SELECT email FROM register WHERE email=?";
	$stmt=$conn->prepare($query);
	$stmt->execute(array($email));
	$results=$stmt->fetch(PDO::FETCH_ASSOC);

	//compare the email in database and inputed email
	if(strcmp($results['email'], $email)==0){
		//create  another query to update
	$query2="UPDATE register SET pword=?  AND cpword=?  WHERE email=?";
	$stmt2=$conn->prepare($query2);

	try{
		$conn->beginTransaction();
		$stmt2->execute(array($pword,$cpword,$results['email']));
		$conn->commit();

		$response['status']='success';
		$response['message']="successfully updated";

	}catch(PDOException $e){

		$conn->rollback();
		$response['status']='error';
		$response['message']="error updating";
	}

	}
	else{

		$response['status']='error';
		$response['message']="error updating";
	}
	header("Content-type:application/json");
	echo json_encode($response);

	}
	


?>