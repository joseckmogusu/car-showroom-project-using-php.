<?php
	session_start();
	ini_set('display_errors','off');
	error_reporting(E_ALL);
	ini_set('log_errors','on');
	ini_set('error_log','error_log.log');

	if("POST" == $_SERVER['REQUEST_METHOD']){
		$email=$_POST['email'];
		$pword=$_POST['pword'];

		login($email,$pword);
	}
	

	function login($email,$pword){
		//create database connection
		$response=array();

		if(strlen($email)==0){
			$response['email_error']="Input your email address";
		}else{
			$email=$email;
		}
		if(strlen($pword)==0){
			$response['pword_error']="Input your password";
		}
		if(!empty($response)){
            $response = $response;
        }else{

	$conn=new PDO("mysql:host=localhost;dbname=cars","root","");
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

		$query="SELECT id FROM register WHERE email=?"; 
		$stmt = $conn->prepare($query);
		$stmt->execute(array($email));
		$login= $stmt->fetch(PDO::FETCH_ASSOC);

		if($login){

	//create  query
	$query="SELECT lname,id,contact from register where email=? AND pword=?";
	$stmt=$conn->prepare($query);
	$stmt->execute(array($email,$pword));
	$results=$stmt->fetch(PDO::FETCH_ASSOC);

	if($results){
		$_SESSION['user']=$results['lname'];
		$_SESSION['uid']=$results['id'];
		$_SESSION['phone']=$results['contact'];
		$_SESSION['email']=$results['email'];
		$response['status']='success';
		$response['message']='Successfuly logged in';
	}
	else{
		$response['status']='error';
		$response['message']="wrong password ";

	}
}else{
	$response['status'] = 'error';
	$response['message'] = 'The email not registered';
}





	header("Content-type:application/json;charset=UTF-8");
	echo json_encode($response);
	}
}




?>